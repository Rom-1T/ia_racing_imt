from gc import callbacks
import numpy as np
import cv2
from donkeycar.parts.ae_config import ROI

DIM = (160, 120)
K = np.array([[76.40210369377033, 0.0, 85.17741324657462], [0.0, 75.55575570884872, 61.5111216120113], [0.0, 0.0, 1.0]])
D = np.array([[0.032858036745614], [-0.09739958496116238], [0.07344214252074698], [-0.02977154953395648]])


class Preprocessing():

    def __init__(self, cfg):
        self.prepro = cfg.PREPROCESSING_METHOD
        self.epaisseur = cfg.EPAISSEUR
        self.undistort = cfg.UNDISTORT
        self.ROI = ROI

    def run(self, image_arr):
        image_arr = crop(undistort(image_arr),self.ROI)
        if self.prepro == "edge":
            img_preprocessed = processing_line_v2(image_arr, mode="edge", reel=False, epaisseur=self.epaisseur)
            img_preprocessed = cv2.cvtColor(img_preprocessed, cv2.COLOR_GRAY2RGB)
        elif self.prepro == "lines":
            img_preprocessed = processing_line_v2(image_arr, mode="lines", reel=False, epaisseur=self.epaisseur)
        elif self.prepro == "final_filter":
            img_preprocessed = final_filter(undistort(image_arr))
        else :
            print("WRONG FILTER TYPE")
            img_preprocessed = image_arr
        return img_preprocessed


def processing_line_v2(image, mode="edge", reel=True, epaisseur=1):
    if reel:
        image = undistort(image)
    edge_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    edge_image = cv2.GaussianBlur(edge_image, (3, 3), 1)
    edge_image = cv2.Canny(edge_image, 150, 200, apertureSize=3)
    edge_image = cv2.dilate(
        edge_image,
        cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5)),
        iterations=epaisseur
    )
    edge_image = cv2.erode(
        edge_image,
        cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5)),
        iterations=epaisseur
    )
    if mode == "edge":
        return edge_image
    else:
        return lines(image, edge_image)


def undistort(img_array):
    # print("UNDISTORT")
    # img_array = np.array(img_array)
    map1, map2 = cv2.fisheye.initUndistortRectifyMap(K, D, np.eye(3), K, DIM, cv2.CV_16SC2)
    undistorted_img = cv2.remap(img_array, map1, map2, interpolation=cv2.INTER_LINEAR,
                                borderMode=cv2.BORDER_CONSTANT)
    return undistorted_img


def lines(img, edges):
    minLineLength = 20
    maxLineGap = 5
    lines = cv2.HoughLinesP(edges, cv2.HOUGH_PROBABILISTIC, np.pi / 180, 30, minLineLength, maxLineGap)

    img = np.zeros((img.shape[0], img.shape[1], 3), dtype="uint8")
    if not (lines is None):
        for x in range(0, len(lines)):
            for x1, y1, x2, y2 in lines[x]:
                pts = np.array([[x1, y1], [x2, y2]], np.int32)
                cv2.polylines(img, [pts], True, (255, 0, 0), 3)
    return img


def final_filter(image):
    image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    image = cv2.GaussianBlur(image, (5, 5), 0)
    threshold = cv2.adaptiveThreshold(image, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 15, 5)
    otsu_threshold, image_result = cv2.threshold(
        image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU,
    )
    filter = cv2.addWeighted(threshold, 1, image_result, 0.5, 0.0)
    filter =  cv2.cvtColor(filter, cv2.COLOR_GRAY2BGR)
    return (filter)

def crop(image,ROI) :
    # Crop
    # Region of interest
    r = ROI
    image = image[int(r[1]) : int(r[1] + r[3]), int(r[0]) : int(r[0] + r[2])]
    return image
